# get a string as input

# initialize result to a empty dictionary

# loop through the letters in the string

    # discard empty spaces

        # if letter in result keys increase the counter
        
            # increase the counter

        # else

            # set the counter to 1
            

# print result
