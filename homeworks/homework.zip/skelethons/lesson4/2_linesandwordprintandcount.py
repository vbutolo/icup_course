# open the file
balls_file = open('balls.txt', 'r')

# get the file as array of lines
balls_lines_array = balls_file.readlines()

# initialite line_count and word_count to 0

# for i in lines
    
    # define splitted as array of words of a single line

    # increment line_count by one

    # for j in words of lines

        # print line number and word number
        
        # increment word_count by one

# print results
