# open the file
balls_file = open('balls.txt', 'r')

# get the file as unique string
balls_file_string = balls_file.read()

# split the string in an array

# set word count

# for in range word_count

# print the word count
