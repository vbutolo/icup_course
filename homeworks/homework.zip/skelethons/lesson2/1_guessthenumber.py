from random import randint

# get a random number from 0 to 100
number = randint(0, 100)

# initialize a tentative counter

# explain the game

# ask user for his first guess

# if guess > number give user the right info

# if guess < number give user the right info

# else the number is correct

# increment tentative by one

# nice formatting

# repeat the same cycle: tentative 2

# repeat the same cycle: tentative 3

# repeat the same cycle: tentative 4

# repeat the same cycle: tentative 5

# repeat the same cycle: tentative 6

# repeat the same cycle: tentative 7

# repeat the same cycle: tentative 8

# repeat the same cycle: tentative 9

# repeat the same cycle: tentative 10

# if guess > number give user the right info and he losts

# if guess < number give user the right info and he losts

# else the number is correct
