# open the file
balls_file = open('balls.txt', 'r')

# get the file as unique string
balls_file_string = balls_file.read()

# split the string in an array

# get the total number of items in the array

# initialize word count

# while counter is true

# formatting

# print the word count
