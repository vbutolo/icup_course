from random import randint

# get a random number from 0 to 100
number = randint(0, 100)

from random import randint

# get a random number from 0 to 100
number = randint(0, 100)

# initialize a tentative counter

# initialite a loop condition

# explain the game

# while looding is true

    # ask user for his guess

    # if guess > number give user the right info

    # if guess < number give user the right info

    # else the number is correct

    # increment tentative by one

    # if tentative has passed 10 stop the loop and communicate the user he losts

    # nice formatting
