# get a string as input
string = input('Insert a string: ')

# initialize result to a empty dictionary
result = {}

# loop through the string content
for letter in string:
    # discard empty spaces
    if letter != ' ':
        # if 
        if value in result.keys():
            result[letter] += 1
        else:
            result[letter] = 1

print(result)
