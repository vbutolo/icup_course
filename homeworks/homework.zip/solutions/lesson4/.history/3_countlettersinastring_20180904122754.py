string = input('Insert a string: ')
result = {}

for i, value in enumerate(string):
    if value in result.keys():
        result[value] += 1
    else:
        result[value] = 1

print(result)
